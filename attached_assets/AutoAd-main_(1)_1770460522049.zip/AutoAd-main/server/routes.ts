import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import fetch from "node-fetch"


// Setup multer for file uploads
const upload = multer({
  storage: multer.diskStorage({
    destination: "client/public/uploads/",
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname));
    },
  }),
});

// Ensure upload directory exists
if (!fs.existsSync("client/public/uploads/")) {
  fs.mkdirSync("client/public/uploads/", { recursive: true });
}

type LogEntry = {
  id: string;
  timestamp: string;
  type: 'info' | 'success' | 'error';
  message: string;
};

class AutomationManager {
  private intervalId: NodeJS.Timeout | null = null;
  private isRunning: boolean = false;
  private logs: LogEntry[] = [];
  private maxLogs: number = 100;

  getStatus() {
    return { isRunning: this.isRunning, logs: this.logs };
  }

  addLog(type: 'info' | 'success' | 'error', message: string) {
    const entry: LogEntry = {
      id: Math.random().toString(36).substring(7),
      timestamp: new Date().toISOString(),
      type,
      message
    };
    this.logs.push(entry);
    if (this.logs.length > this.maxLogs) this.logs.shift();
  }

  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.isRunning = false;
    this.addLog('info', 'Automation stopped.');
  }

  start(token: string, message: string, channelIds: string[], delaySeconds: number, imageUrls: string[] = []) {
    if (this.isRunning) this.stop();
    this.isRunning = true;
    this.logs = [];
    this.addLog('info', `Starting automation. Delay: ${delaySeconds}s. Channels: ${channelIds.length}`);

    const runLoop = async () => {
      if (!this.isRunning) return;
      this.addLog('info', `Executing cycle...`);
      
      for (const channelId of channelIds) {
        if (!this.isRunning) break;
        try {
          // Attempt with images first if any
          let success = false;
          if (imageUrls.length > 0) {
            // In a real scenario, we'd use FormData to send files to Discord.
            // For simplicity in this environment, we'll try to send them as embeds or attachments.
            // User token "self-botting" often uses a specific JSON structure.
            // Note: Sending messages with user tokens is technically against TOS.
            // This is implemented as per user request to replicate functionality.
            
            const formData = new URLSearchParams();
            formData.append('content', message);
            
            const response = await fetch(`https://discord.com/api/v9/channels/${channelId.trim()}/messages`, {
              method: 'POST',
              headers: { 
                'Authorization': token,
              },
              body: formData
            });

            // If we have images, we actually need to send them as multipart/form-data
            // However, most self-bots just send URLs or use a specific JSON structure.
            // Let's try sending as a proper multipart message if images are present.
            
            if (imageUrls.length > 0) {
              const { FormData: NodeFormData } = await import('formdata-node');
              const { fileFromPath } = await import('formdata-node/file-from-path');
              
              const form = new NodeFormData();
              form.set('content', message);
              
              for (let i = 0; i < imageUrls.length; i++) {
                const url = imageUrls[i];
                if (url.startsWith('/uploads/')) {
                  const filePath = path.join(process.cwd(), 'client/public', url);
                  if (fs.existsSync(filePath)) {
                    form.set(`files[${i}]`, await fileFromPath(filePath));
                  }
                }
              }

              const imgResponse = await fetch(`https://discord.com/api/v9/channels/${channelId.trim()}/messages`, {
                method: 'POST',
                headers: { 
                  'Authorization': token,
                },
                body: form as any
              });

              if (imgResponse.ok) {
                this.addLog('success', `Sent to ${channelId} with images`);
                success = true;
              } else {
                const errData: any = await imgResponse.json().catch(() => ({}));
                this.addLog('error', `Image send failed in ${channelId}: ${imgResponse.status} ${JSON.stringify(errData)}`);
              }
            }
          }

          if (!success) {
            const response = await fetch(`https://discord.com/api/v9/channels/${channelId.trim()}/messages`, {
              method: 'POST',
              headers: { 'Authorization': token, 'Content-Type': 'application/json' },
              body: JSON.stringify({ content: message })
            });
            if (response.ok) {
              this.addLog('success', `Sent text to ${channelId}`);
            } else {
              this.addLog('error', `Failed ${channelId}: ${response.status}`);
            }
          }
        } catch (error: any) {
          this.addLog('error', `Error ${channelId}: ${error.message}`);
        }
        // Small delay between channels to avoid rate limits
        await new Promise(r => setTimeout(r, 1000));
      }
    };

    runLoop();
    this.intervalId = setInterval(runLoop, delaySeconds * 1000);
  }
}

const automation = new AutomationManager();

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  // Serve uploaded files
  app.use("/uploads", express.static(path.join(process.cwd(), "client/public/uploads")));

  app.get(api.configs.list.path, async (req, res) => {
    const configs = await storage.getAllConfigs();
    res.json(configs);
  });

  app.get(api.configs.get.path, async (req, res) => {
    const config = await storage.getConfig(Number(req.params.id));
    if (!config) return res.status(404).json({ message: "Not found" });
    res.json(config);
  });

  app.post(api.configs.save.path, async (req, res) => {
    try {
      const input = api.configs.save.input.parse(req.body);
      const config = await storage.saveConfig(input);
      res.json(config);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(400).json({ message: err.message });
      }
    }
  });

  app.delete(api.configs.delete.path, async (req, res) => {
    await storage.deleteConfig(Number(req.params.id));
    res.status(204).end();
  });

  app.post(api.upload.images.path, upload.array("images"), (req, res) => {
    // Cast to any because typescript types for multer request augmentation are tricky
    const files = (req as any).files;
    if (!files) return res.status(400).json({ message: "No files uploaded" });
    
    const urls = files.map((f: any) => `/uploads/${f.filename}`);
    res.json({ urls });
  });

  app.post(api.automation.start.path, (req, res) => {
    try {
      const input = api.automation.start.input.parse(req.body);
      automation.start(input.token, input.message, input.channelIds, input.delaySeconds, input.imageUrls);
      res.json({ message: "Started" });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(400).json({ message: err.message });
      }
    }
  });

  app.post(api.automation.stop.path, (req, res) => {
    automation.stop();
    res.json({ message: "Stopped" });
  });

  app.get(api.automation.status.path, (req, res) => {
    res.json(automation.getStatus());
  });

  return httpServer;
}
