## Packages
framer-motion | For smooth animations and terminal effects

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  mono: ["'Fira Code'", "'JetBrains Mono'", "monospace"],
  display: ["'Fira Code'", "monospace"],
  body: ["'JetBrains Mono'", "monospace"],
}
